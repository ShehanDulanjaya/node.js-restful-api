import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-router-deactivate',
  templateUrl: './router-deactivate.component.html',
  styleUrls: ['./router-deactivate.component.scss']
})
export class RouterDeactivateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
