import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cdk-d3-usa',
  templateUrl: './d3-usa.component.html',
  styleUrls: ['./d3-usa.component.scss']
})
export class D3UsaComponent implements OnInit {
  ngOnInit(){
    
  }
  
}
